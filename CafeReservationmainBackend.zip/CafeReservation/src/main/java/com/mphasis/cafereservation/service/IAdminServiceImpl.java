package com.mphasis.cafereservation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Admin;
import com.mphasis.cafereservation.repository.IAdminRepository;

@Service
public class IAdminServiceImpl implements IAdminService{
	
	@Autowired
	IAdminRepository adminRepository;
	
	public Admin addAdmin(Admin admin) {
		adminRepository.save(admin);
		return admin;
	}
	public Admin updateAdmin(Admin admin) {
		Admin a = adminRepository.getAdminByEmail(admin.getAdminEmail());
		admin.setAdminId(a.getAdminId());
		adminRepository.save(admin);
		return admin;
	}
	public Admin getAdminByEmail(String email) {
		return adminRepository.getAdminByEmail(email);
	}
}
