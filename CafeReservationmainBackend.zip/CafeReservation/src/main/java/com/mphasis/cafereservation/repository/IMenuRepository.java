package com.mphasis.cafereservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.cafereservation.entity.CafeMenu;
@Repository
public interface IMenuRepository extends JpaRepository<CafeMenu, Integer>{
	
	@Query("select m from CafeMenu m where m.itemName=:item")
	public CafeMenu getByName(@Param("item")String itemName);
	
	@Query("select m from CafeMenu m where m.category=:temp and m.isAvailable='Available'")
	public List<CafeMenu> getMenuByCategory(@Param("temp") String temp);
	
	@Query("select m from CafeMenu m where m.isAvailable=:temp")
	public List<CafeMenu> getMenuByStatus(@Param("temp") String status);
	
	@Query("select m from CafeMenu m where m.price<=:rate")
	public List<CafeMenu> getMenuByPrice(@Param("rate")double price);
	
	
	
}

