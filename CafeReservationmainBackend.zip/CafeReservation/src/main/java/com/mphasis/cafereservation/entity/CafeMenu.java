package com.mphasis.cafereservation.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "cafemenu_tbl")
public class CafeMenu {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="item_id")
	int itemId;
	@Column(name="item_name")
	String itemName;
	@Column
	double price;
	@Column
	String description;
	@Column(name="is_available")
	String isAvailable;
	@Column
	String category;
	@Column
	LocalDateTime created;
	@Column
	LocalDateTime updated;
	@Column
	String image;
	public CafeMenu() {
		super();
	}
	public CafeMenu(int itemId, String itemName, double price, String description, String isAvailable, String category,
			LocalDateTime created, LocalDateTime updated) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.description = description;
		this.isAvailable = isAvailable;
		this.category = category;
		this.created = created;
		this.updated = updated;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDateTime getCreated() {
		return created;
	}
	public void setCreated(LocalDateTime created) {
		this.created = created;
	}
	public LocalDateTime getUpdated() {
		return updated;
	}
	public void setUpdated(LocalDateTime updated) {
		this.updated = updated;
	}
	@Override
	public String toString() {
		return "Menu [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", description=" + description
				+ ", isAvailable=" + isAvailable + ", category=" + category + ", created=" + created + ", updated="
				+ updated + "]";
	}
}
