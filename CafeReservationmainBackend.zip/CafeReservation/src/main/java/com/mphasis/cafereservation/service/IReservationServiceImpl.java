package com.mphasis.cafereservation.service;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.mphasis.cafereservation.entity.Reservation;
import com.mphasis.cafereservation.repository.IReservationRepository;
 
@Service
public class IReservationServiceImpl implements IReservationService{
 
	@Autowired
	IReservationRepository reservationRepository;
	public Reservation addReservation(Reservation reservation) {
		reservation.setBookingdate(LocalDateTime.now());
		reservation.setStatus("Pending");
	    Reservation reservation1=reservationRepository.save(reservation);
	    return reservation1;
	}
	public List<Reservation> getAllReservations(){
		return reservationRepository.findAll();		
	}
	public Reservation updateReservationStatus(int reservationId) {
		Optional<Reservation> op=reservationRepository.findById(reservationId);
		Reservation reservation=op.get();
		reservation.setStatus("confirmed");		
		Reservation reservation1= reservationRepository.save(reservation);
		return reservation1; 
	}
	public Reservation cancelReservation(int reservationId) {
		Optional<Reservation> op=reservationRepository.findById(reservationId);
		Reservation reservation=op.get();
		reservationRepository.deleteById(reservationId);
		return reservation;
	}
	public Reservation getReservationById(int reservationId) {
		Optional<Reservation> op=reservationRepository.findById(reservationId);
		Reservation reservation=op.get();
		return reservation;
	}
	public Reservation updateReservation(Reservation reservation) {
		if(!reservationRepository.existsById(reservation.getReservationId())) {
			return null;
		}
		return reservationRepository.save(reservation);
	}
 
	
	public List<Reservation> getReservation(String email) {
		return reservationRepository.getReservation(email);
	}
	public boolean idExits(int id) {
		return reservationRepository.existsById(id); 
	}
}
