package com.mphasis.cafereservation.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.CafeMenu;
import com.mphasis.cafereservation.repository.IMenuRepository;

@Service
public class IMenuServiceImpl implements IMenuService {

	@Autowired
	IMenuRepository menuRepository;
	
	public CafeMenu addMenu(CafeMenu menu) {
		menu.setCreated(LocalDateTime.now());
		menu.setUpdated(LocalDateTime.now());
		menuRepository.save(menu);
		return menu;
	}
	
	public CafeMenu updateMenu(CafeMenu menu) {
		CafeMenu menu1 = menuRepository.getByName(menu.getItemName());
		menu.setItemId(menu1.getItemId());
		menu.setUpdated(LocalDateTime.now());
		menuRepository.save(menu);
		return menu;
	}
	public CafeMenu getByName(String item) {
		return menuRepository.getByName(item);
	}
	
	public CafeMenu deleteById(int id) {
		CafeMenu menu = menuRepository.findById(id).get();
		menuRepository.deleteById(id);
		return menu;
	}
	
	public List<CafeMenu> getAll(){
		return menuRepository.findAll();
	}
	
	public List<CafeMenu> getMenuByCategory(String temp) {
		return menuRepository.getMenuByCategory(temp);
	}
	
	public List<CafeMenu> getMenuByStatus(String  status) {
		return menuRepository.getMenuByStatus(status);
	}
	
	public List<CafeMenu> getMenuByPrice(double price) {
		return menuRepository.getMenuByPrice(price);
	}

	public CafeMenu getMenuById(int id) {
		return menuRepository.findById(id).get();
	}
	
	
}
