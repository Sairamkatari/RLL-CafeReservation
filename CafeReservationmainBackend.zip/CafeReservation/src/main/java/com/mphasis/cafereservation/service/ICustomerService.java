package com.mphasis.cafereservation.service;

import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Customer;
@Service
public interface ICustomerService {
	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer getCustomerByEmail(String email);
}
