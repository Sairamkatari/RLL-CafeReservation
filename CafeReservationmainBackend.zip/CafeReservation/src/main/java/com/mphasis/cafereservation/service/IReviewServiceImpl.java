package com.mphasis.cafereservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Reviews;
import com.mphasis.cafereservation.repository.IReviewRepository;

@Service
public class IReviewServiceImpl implements IReviewService {

	@Autowired
	IReviewRepository reviewRepository;
	
	@Override
	public Reviews addReview(Reviews review) {
		reviewRepository.save(review);
		return review;
	}

	@Override
	public List<Reviews> getReviews() {
		return reviewRepository.findAll();
	}

}
