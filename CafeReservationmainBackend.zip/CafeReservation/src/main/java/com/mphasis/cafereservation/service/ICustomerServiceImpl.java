package com.mphasis.cafereservation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Customer;
import com.mphasis.cafereservation.repository.ICustomerRepository;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepository customerRepository;
	
	public Customer addCustomer(Customer customer) {
		customerRepository.save(customer);
		return customer;
	}
	public Customer updateCustomer(Customer customer) {
		Customer c = customerRepository.getCustomerByEmail(customer.getCustomerEmail());
		customer.setCustomerId(c.getCustomerId());
		customerRepository.save(customer);
		return customer;
	}
	public Customer getCustomerByEmail(String email) {
		return customerRepository.getCustomerByEmail(email);
	}

}
