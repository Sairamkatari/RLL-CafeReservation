package com.mphasis.cafereservation.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "reservation_tbl")
public class Reservation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="reservation_id")
	int reservationId;
	@Column(name="visit_date")
	LocalDate visitDate;
	@Column(name="visit_time")
	String visitTime;
	@Column
	LocalDateTime bookingdate;	
	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	Customer customer;
	 @OneToMany(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	 List<CafeTable> tableList; 
	@Column(name="no_of_people")
	int noOfPeople;
	@Column
	String status;
	@Column
	String message;
	
	public Reservation() {
		super();
	}

	public Reservation(int reservationId, LocalDate visitDate, String visitTime, LocalDateTime bookingdate,
			Customer customer, List<CafeTable> tableList, int noOfPeople, String status, String message) {
		super();
		this.reservationId = reservationId;
		this.visitDate = visitDate;
		this.visitTime = visitTime;
		this.bookingdate = bookingdate;
		this.customer = customer;
		this.tableList = tableList;
		this.noOfPeople = noOfPeople;
		this.status = status;
		this.message = message;
	}

	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public LocalDate getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(LocalDate visitDate) {
		this.visitDate = visitDate;
	}

	public String getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}

	public LocalDateTime getBookingdate() {
		return bookingdate;
	}

	public void setBookingdate(LocalDateTime bookingdate) {
		this.bookingdate = bookingdate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<CafeTable> getTableList() {
		return tableList;
	}

	public void setTableList(List<CafeTable> tableList) {
		this.tableList = tableList;
	}

	public int getNoOfPeople() {
		return noOfPeople;
	}

	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Reservation [reservationId=" + reservationId + ", visitDate=" + visitDate + ", visitTime=" + visitTime
				+ ", bookingdate=" + bookingdate + ", customer=" + customer + ", tableList=" + tableList
				+ ", noOfPeople=" + noOfPeople + ", status=" + status + ", message=" + message + "]";
	}
	
		
}
