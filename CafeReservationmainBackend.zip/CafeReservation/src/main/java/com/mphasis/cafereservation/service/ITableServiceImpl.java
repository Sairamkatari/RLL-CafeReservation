package com.mphasis.cafereservation.service;
 

import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.mphasis.cafereservation.entity.CafeTable;
import com.mphasis.cafereservation.repository.ITableRepository;
 
@Service
public class ITableServiceImpl implements ITableService{
 
	@Autowired
	ITableRepository tableRepository;
	public CafeTable addTable(CafeTable table) {
		table.setIsAvailable("Available");
		CafeTable cafeTable=tableRepository.save(table);
		return cafeTable;
	}
	public CafeTable updateTableAvailability(int tableId) {		
		Optional<CafeTable> op=tableRepository.findById(tableId);
		CafeTable table=op.get();
		table.setIsAvailable("Not Available");
		CafeTable table1= tableRepository.save(table);
		return table1;			
		}
	public CafeTable deleteTable(int tableId) {
		Optional<CafeTable> op=tableRepository.findById(tableId);
		CafeTable table=op.get();
		tableRepository.deleteById(tableId);
		return table;
	}
	public List<CafeTable> getAllTables(){
		return tableRepository.findAll();
	}
	public List<CafeTable> getTablesByRoomType(String roomType){
		return tableRepository.getTablesByRoomType(roomType);
	}
	public CafeTable getTablesById(int tableId){
		Optional<CafeTable> op= tableRepository.findById(tableId);		
		return op.get();
	}
	public List<CafeTable> getTablesByAvailability(String isAvailable){
		return tableRepository.getTablesByAvailability(isAvailable);		
	}
	public CafeTable updateTable(CafeTable table) {
		if (!tableRepository.existsById(table.getTableId())) {
		  return null;
		}
		return tableRepository.save(table);
	}
	public boolean idExits(int id) {
		return tableRepository.existsById(id); 
	}
	}
 