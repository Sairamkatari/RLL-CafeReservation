package com.mphasis.cafereservation.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Reviews;

@Service
public interface IReviewService {
	
	public Reviews addReview(Reviews review);
	public List<Reviews> getReviews();

}
