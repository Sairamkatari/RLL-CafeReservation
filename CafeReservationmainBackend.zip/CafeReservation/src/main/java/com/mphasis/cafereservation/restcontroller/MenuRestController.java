package com.mphasis.cafereservation.restcontroller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.mphasis.cafereservation.entity.CafeMenu;
import com.mphasis.cafereservation.service.IMenuServiceImpl;
 
@CrossOrigin("*")
@RestController
@RequestMapping("/menu")
public class MenuRestController {
 
	@Autowired
	IMenuServiceImpl menuService;
	@PostMapping("/addmenu")
	public CafeMenu addMenu(@RequestBody CafeMenu menu) {
		return menuService.addMenu(menu);
	}
	@PutMapping("/updatemenu")
	public CafeMenu updateMenu(@RequestBody CafeMenu menu) {
		return menuService.updateMenu(menu);
	}
	@GetMapping("/getmenu")
	public ResponseEntity<?> getAll(){
		List<CafeMenu> menuList= menuService.getAll();
		if(menuList.isEmpty()) {
			return new ResponseEntity<String>("Menu List is empty",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeMenu>>(menuList,HttpStatus.OK);
		}
	}
	@GetMapping("/getmenubycategory/{category}")
	public ResponseEntity<?> getMenuByCategory(@PathVariable("category") String category) {
		List<CafeMenu> menuList= menuService.getMenuByCategory(category);
		if(menuList.isEmpty()) {
			return new ResponseEntity<String>("Menu List is empty for this category",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeMenu>>(menuList,HttpStatus.OK);
		}
	}
	@GetMapping("/getmenubystatus/{status}")
	public ResponseEntity<?> getMenuByStatus(@PathVariable("status") String  status) {
		List<CafeMenu> menuList= menuService.getMenuByStatus(status);
		if(menuList.isEmpty()) {
			return new ResponseEntity<String>("Menus not found for this status",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeMenu>>(menuList,HttpStatus.OK);
		}
	}
	@GetMapping("/getmenubyid/{id}")
	public ResponseEntity<?> getMenuById(@PathVariable("id") int id) {
		CafeMenu menu= menuService.getMenuById(id);
		if(menu!=null) {
			return new ResponseEntity<CafeMenu>(menu,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("Menu Item not Found",HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/getmenubyprice/{price}")
	public ResponseEntity<?> getMenuByPrice(@PathVariable("price") double price) {
		List<CafeMenu> menuList= menuService.getMenuByPrice(price);
		if(menuList.isEmpty()) {
			return new ResponseEntity<String>("Menus not found for this price",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeMenu>>(menuList,HttpStatus.OK);
		}
	}
	@GetMapping("/getmenubyname/{item}")
	public ResponseEntity<?> getByName(@PathVariable("item") String item) {
		CafeMenu menu= menuService.getByName(item);
		if(menu!=null) {
			return new ResponseEntity<CafeMenu>(menu,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("Menu Item not Found",HttpStatus.NOT_FOUND);
		}
	}
	@DeleteMapping("/deletemenu/{id}")
	public ResponseEntity<?> deleteById(@PathVariable("id") int id) {
		CafeMenu menu= menuService.deleteById(id);
		if(menu!=null) {
			return new ResponseEntity<CafeMenu>(menu,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("Menu Item not Found",HttpStatus.NOT_FOUND);
		}
	}
}