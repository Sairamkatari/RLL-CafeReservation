package com.mphasis.cafereservation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cafe_tbl")
public class CafeTable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int tableId;
	@Column(name="room_type")
	String roomType;
	@Column(name="is_available")
	String isAvailable;
	@Column
	int capacity;
	public CafeTable() {
		super();
	}
	public CafeTable(int tableId, String roomType, String isAvailable, int capacity) {
		super();
		this.tableId = tableId;
		this.roomType = roomType;
		this.isAvailable = isAvailable;
		this.capacity = capacity;
	}
	public int getTableId() {
		return tableId;
	}
	public void setTableId(int tableId) {
		this.tableId = tableId;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String toString() {
		return "CafeTable [tableId=" + tableId + ", roomType=" + roomType + ", isAvailable=" + isAvailable
				+ ", capacity=" + capacity + "]";
	}
}
