package com.mphasis.cafereservation.restcontroller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.mphasis.cafereservation.entity.Customer;
import com.mphasis.cafereservation.service.ICustomerServiceImpl;
 
@CrossOrigin("*")
@RestController
@RequestMapping("/customer")
public class CustomerRestController {
 
	@Autowired
	ICustomerServiceImpl customerService;
	
	@PostMapping("/addcustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
	}
	@PutMapping("/updatecustomer")
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer);
	}
	
	@GetMapping("/getcustomerbyemail/{email}")
	public ResponseEntity<?> getCustomerByEmail(@PathVariable("email") String email) {
		Customer customer= customerService.getCustomerByEmail(email);
		if(customer!=null) {
			return new ResponseEntity<Customer>(customer,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("Customer not found",HttpStatus.NOT_FOUND);
		}
		
	}
}
 