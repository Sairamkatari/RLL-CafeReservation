package com.mphasis.cafereservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.cafereservation.entity.Admin;
@Repository
public interface IAdminRepository extends JpaRepository<Admin, Integer>{

	@Query("select a from Admin a where a.adminEmail = :email")
	public Admin getAdminByEmail(@Param("email") String email);
}
