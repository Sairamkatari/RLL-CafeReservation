package com.mphasis.cafereservation.service;

import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.Admin;
@Service
public interface IAdminService {
	public Admin addAdmin(Admin admin);
	public Admin updateAdmin(Admin admin);
	public Admin getAdminByEmail(String email);
}
