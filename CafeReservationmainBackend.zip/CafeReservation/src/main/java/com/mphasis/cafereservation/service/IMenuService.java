package com.mphasis.cafereservation.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.cafereservation.entity.CafeMenu;
@Service
public interface IMenuService {
	public CafeMenu addMenu(CafeMenu menu);
	public CafeMenu updateMenu(CafeMenu menu);
	public CafeMenu getByName(String item);
	public CafeMenu deleteById(int id);
	public List<CafeMenu> getAll();
	public List<CafeMenu> getMenuByCategory(String temp);
	public List<CafeMenu> getMenuByStatus(String  status);
	public List<CafeMenu> getMenuByPrice(double price);
	public CafeMenu getMenuById(int id);
}
