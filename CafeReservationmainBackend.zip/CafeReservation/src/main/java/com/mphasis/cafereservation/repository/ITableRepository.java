package com.mphasis.cafereservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mphasis.cafereservation.entity.CafeTable;
@Repository
public interface ITableRepository extends JpaRepository<CafeTable, Integer>{
	@Query("select table from CafeTable table where table.roomType=:type")
	public List<CafeTable> getTablesByRoomType(@Param("type")String roomType);
	
	@Query("select table from CafeTable table where table.isAvailable=:isAvailable")
	public List<CafeTable> getTablesByAvailability(@Param("isAvailable")String isAvailable);
}
