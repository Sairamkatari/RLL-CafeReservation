package com.mphasis.cafereservation.service;
 
import java.util.List;
 
import org.springframework.stereotype.Service;
 
import com.mphasis.cafereservation.entity.CafeTable;
@Service
public interface ITableService {
	public CafeTable addTable(CafeTable table);
	public CafeTable updateTableAvailability(int tableId);
	public CafeTable deleteTable(int tableId);
	public List<CafeTable> getAllTables();
	public List<CafeTable> getTablesByRoomType(String roomType);
	public CafeTable getTablesById(int tableId);
	public CafeTable updateTable(CafeTable table);
	public boolean idExits(int id);
}