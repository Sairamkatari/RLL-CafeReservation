package com.mphasis.cafereservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.cafereservation.entity.Reviews;
@Repository
public interface IReviewRepository extends JpaRepository<Reviews, Integer>{

}
