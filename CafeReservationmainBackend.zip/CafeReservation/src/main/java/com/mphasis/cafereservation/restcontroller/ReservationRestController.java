package com.mphasis.cafereservation.restcontroller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.mphasis.cafereservation.entity.Reservation;
import com.mphasis.cafereservation.service.IReservationServiceImpl;
@CrossOrigin("*")
@RestController
@RequestMapping("/reservation")
public class ReservationRestController {
	@Autowired
	IReservationServiceImpl reservationService;
	@PostMapping("/addreservation")
	public Reservation addReservation(@RequestBody Reservation reservation) {
		return reservationService.addReservation(reservation);
	}
	@GetMapping("/getallreservations")
	public ResponseEntity<?> getAllReservations(){
		List<Reservation> rList=reservationService.getAllReservations();
		if(rList.isEmpty()) {
			return new ResponseEntity<String>("List is empty",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Reservation>>(rList,HttpStatus.OK);
	}
	@PutMapping("/updatereservationstatus/{reservationId}")
	public ResponseEntity<?> updateReservationStatus(@PathVariable int reservationId) {
		if(reservationService.idExits(reservationId)) {
			Reservation reserve= reservationService.updateReservationStatus(reservationId);
			return new ResponseEntity<Reservation>(reserve, HttpStatus.OK)	;	
		}
		else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@DeleteMapping("/cancelreservation/{reservationId}")
	public ResponseEntity<?> cancelReservation(@PathVariable int reservationId) {
		if(reservationService.idExits(reservationId)) {
		Reservation reserve=reservationService.cancelReservation(reservationId);
		return new ResponseEntity<Reservation>(reserve, HttpStatus.OK)	;	
		}
		else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/getreservationbyid/{reservationId}")
	public ResponseEntity<?> getReservationById(@PathVariable int reservationId) {	
		if(reservationService.idExits(reservationId)) {
			Reservation reserve= reservationService.getReservationById(reservationId);
			return new ResponseEntity<Reservation>(reserve, HttpStatus.OK)	;		
		}else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@PutMapping("/updatereservation")
	public Reservation updateReservation(@RequestBody Reservation reservation) {
		return reservationService.updateReservation(reservation);
	}
	@GetMapping("/getByCustomerId/{email}")
	public ResponseEntity<?> getReservation(@PathVariable("email") String  email){
		List<Reservation> rList=reservationService.getReservation(email);
		if(rList.isEmpty()) {
			return new ResponseEntity<String>("List is empty for this customer",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Reservation>>(rList,HttpStatus.OK);
	}
 
}