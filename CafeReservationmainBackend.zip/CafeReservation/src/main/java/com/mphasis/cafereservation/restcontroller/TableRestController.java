package com.mphasis.cafereservation.restcontroller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.mphasis.cafereservation.entity.CafeTable;
import com.mphasis.cafereservation.service.ITableServiceImpl;
 
@CrossOrigin("*")
@RestController
@RequestMapping("/table")
public class TableRestController {
	@Autowired
	ITableServiceImpl tableService;
	@PostMapping("/addtable")
	public CafeTable addTable(@RequestBody CafeTable table) {
		return tableService.addTable(table);		
	}
	@PutMapping("/updateavailability/{tableId}")
	public ResponseEntity<?> updateTableAvailability(@PathVariable("tableId") int tableId) {
		if(tableService.idExits(tableId)) {
			CafeTable table= tableService.updateTableAvailability(tableId);
			return new ResponseEntity<CafeTable>(table,HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@DeleteMapping("/deletetable/{tableId}")
	public ResponseEntity<?> deleteTable(@PathVariable("tableId") int tableId) {
		if(tableService.idExits(tableId)) {
			CafeTable table= tableService.deleteTable(tableId);
			return new ResponseEntity<CafeTable>(table,HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/getalltables")
	public ResponseEntity<?> getAllTables(){
		List<CafeTable> tList=tableService.getAllTables();	
		if(tList.isEmpty()) {
			return new ResponseEntity<String>("Table List is Empty",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeTable>>(tList,HttpStatus.OK);
		}
	}
	@GetMapping("/gettablesbyroom/{roomType}")
	public ResponseEntity<?> getTablesByRoomType(@PathVariable("roomType") String roomType){ 	
		List<CafeTable> tList=tableService.getTablesByRoomType(roomType);	
		if(tList.isEmpty()) {
			return new ResponseEntity<String>("Room type is not found",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeTable>>(tList,HttpStatus.OK);
		}
	}
	@GetMapping("/gettablebyid/{tableId}")
	public ResponseEntity<?> getTablesById(@PathVariable("tableId") int tableId){		 
		if(tableService.idExits(tableId)) {
			CafeTable table= tableService.getTablesById(tableId);
			return new ResponseEntity<CafeTable>(table,HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("Id not Found",HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/gettablesbyAvailability/{isAvailable}")
	public ResponseEntity<?> getTablesByAvailability(@PathVariable("isAvailable") String isAvailable){ 
		List<CafeTable> tList=tableService.getTablesByAvailability(isAvailable);	
		if(tList.isEmpty()) {
			return new ResponseEntity<String>("Room type is not found",HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<List<CafeTable>>(tList,HttpStatus.OK);
		}
	}
	@PutMapping("/updatetable")
	public CafeTable updateTable(@RequestBody CafeTable table) {
		return tableService.updateTable(table);
	}
 
}