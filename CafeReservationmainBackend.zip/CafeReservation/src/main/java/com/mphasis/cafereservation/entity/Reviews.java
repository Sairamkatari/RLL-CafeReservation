package com.mphasis.cafereservation.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "review_tbl")
public class Reviews {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="review_id")
	int reviewId;
	@Column(name="comments")
	String comments;
	@Column(name="ratings")
	int ratings;
	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	Customer customer;
	public Reviews() {
		super();
	}
	public Reviews(int reviewId, String comments, int ratings, Customer customer) {
		super();
		this.reviewId = reviewId;
		this.comments = comments;
		this.ratings = ratings;
		this.customer = customer;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Reviews [reviewId=" + reviewId + ", comments=" + comments + ", ratings=" + ratings + ", customer="
				+ customer + "]";
	}
}