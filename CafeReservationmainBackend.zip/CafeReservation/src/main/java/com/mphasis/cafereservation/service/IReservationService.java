package com.mphasis.cafereservation.service;
 
import java.util.List;
 
import org.springframework.stereotype.Service;
 
import com.mphasis.cafereservation.entity.Reservation;
@Service
public interface IReservationService {
	public Reservation addReservation(Reservation reservation);
	public List<Reservation> getAllReservations();
	public Reservation updateReservationStatus(int reservationId);
	public Reservation cancelReservation(int reservationId);
	public Reservation getReservationById(int reservationId);
	public Reservation updateReservation(Reservation reservation);
	public List<Reservation> getReservation(String cid);
	public boolean idExits(int id);
}