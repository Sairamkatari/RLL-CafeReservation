package com.cafereservation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mphasis.cafereservation.CafeReservationApplication;
import com.mphasis.cafereservation.entity.Admin;
import com.mphasis.cafereservation.entity.CafeMenu;
import com.mphasis.cafereservation.entity.CafeTable;
import com.mphasis.cafereservation.entity.Customer;
import com.mphasis.cafereservation.entity.Reservation;
import com.mphasis.cafereservation.service.IAdminServiceImpl;
import com.mphasis.cafereservation.service.ICustomerServiceImpl;
import com.mphasis.cafereservation.service.IMenuServiceImpl;
import com.mphasis.cafereservation.service.IReservationServiceImpl;
import com.mphasis.cafereservation.service.ITableServiceImpl;

import jakarta.transaction.Transactional;

@SpringBootTest(classes = CafeReservationApplication.class)
@Transactional
class CafeReservationApplicationTests {

	
	@Autowired
	IAdminServiceImpl adminService;
	
	@Autowired
	IMenuServiceImpl menuService;
	
	@Autowired
	ITableServiceImpl tableService;
	
	@Autowired
	ICustomerServiceImpl custservice;
	
	@Autowired
	IReservationServiceImpl reservationservice;
 
	
	
	
	
//	******************* Admin Test Cases ***********************
//	
//	public void addAdmin() {
//		Admin admin = new Admin();
//		admin.setAdminName("Test");
//		admin.setAdminEmail("test@gmail.com");
//		admin.setAdminContact(9876543210l);
//		admin.setAdminPassword("Test@123");
//		adminService.addAdmin(admin);
//	}
//	
//	
//	
//	@Test
//	public void testGetadminByEmail() {
//		
//		addAdmin();
//		Admin testAdmin = adminService.getAdminByEmail("test@gmail.com");
//		
//		assertEquals("Test", testAdmin.getAdminName());
//		assertEquals("test@gmail.com", testAdmin.getAdminEmail());
//		assertEquals(9876543210l, testAdmin.getAdminContact());
//		assertEquals("Test@123", testAdmin.getAdminPassword());
//	}
//	
//	@Test
//	public void testAddAdmin() {
//		Admin admin = new Admin();
//		admin.setAdminName("Test1");
//		admin.setAdminEmail("test1@gmail.com");
//		admin.setAdminContact(9876543210l);
//		admin.setAdminPassword("Test@123");
//		adminService.addAdmin(admin);
//		
//		Admin testAdmin = adminService.getAdminByEmail("test1@gmail.com");
//		assertEquals(admin.getAdminName(), testAdmin.getAdminName());
//		assertEquals(admin.getAdminEmail(), testAdmin.getAdminEmail());
//		assertEquals(admin.getAdminContact(), testAdmin.getAdminContact());
//		assertEquals(admin.getAdminPassword(), testAdmin.getAdminPassword());
//	}
//	
//	@Test
//	public void testUpdateAdmin() {
//		Admin testAdmin = adminService.getAdminByEmail("test1@gmail.com");
//		testAdmin.setAdminPassword("Changed@123");
//		adminService.updateAdmin(testAdmin);
//		Admin testAdmin1 = adminService.getAdminByEmail("test1@gmail.com");
//		
//		assertEquals("Changed@123", testAdmin1.getAdminPassword());
//	}
//
////******************* CafeMenu Test Cases ***********************
//	
//	@Test
//	public void testAddMenu() {
//		
//		CafeMenu menu = new CafeMenu();
//		menu.setItemName("Dosa");
//		menu.setCategory("breakfast");
//		menu.setIsAvailable("Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(10.5);
//		
//		menuService.addMenu(menu);
//		CafeMenu testMenu = menuService.getByName("Dosa");
//		assertEquals(menu.getItemName(), testMenu.getItemName());
//		assertEquals(menu.getCategory(), testMenu.getCategory());
//		assertEquals(menu.getPrice(), testMenu.getPrice());
//	}
//	
//	
//	@Test
//	public void testUpdate() {
//
//		CafeMenu menu = new CafeMenu();
//		menu.setItemName("Idly");
//		menu.setCategory("breakfast");
//		menu.setIsAvailable("Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(10.5);
//		menuService.addMenu(menu);
//		CafeMenu testMenu = menuService.getByName("Idly");
//		testMenu.setPrice(200);
//		CafeMenu testMenu2 = menuService.getByName("Idly");
//		assertEquals(testMenu.getIsAvailable(), testMenu2.getIsAvailable());
//		
//	}
//	
//	@Test
//	public void deleteMenu() {
//		CafeMenu menu = new CafeMenu();
//		menu.setItemName("Coffee");
//		menu.setCategory("breakfast");
//		menu.setIsAvailable("Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(50);
//		menuService.addMenu(menu);
//		CafeMenu testMenu1 = menuService.getByName("Coffee");
//		CafeMenu testMenu = menuService.deleteById(testMenu1.getItemId());
//		assertEquals(menu.getCategory(), testMenu.getCategory());
//	}
//	
//	@Test
//	public void getMenuByName() {
//		CafeMenu menu = new CafeMenu();
//		menu.setItemName("Coffee");
//		menu.setCategory("breakfast");
//		menu.setIsAvailable("Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(50);
//		menuService.addMenu(menu);
//		CafeMenu testMenu1 = menuService.getByName("Coffee");
//		assertNotNull(testMenu1);
//	}
//	
//	
//	public void testGetAll() {
//		CafeMenu menu = new CafeMenu();
//		menu.setItemName("Pizza");
//		menu.setCategory("dinner");
//		menu.setIsAvailable("Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(400);
//		menuService.addMenu(menu);
//		menu = new CafeMenu();
//		menu.setItemName("IceCream");
//		menu.setCategory("Desserts");
//		menu.setIsAvailable("Not Available");
//		menu.setDescription("test menu item");
//		menu.setCreated(LocalDateTime.now());
//		menu.setUpdated(LocalDateTime.now());
//		menu.setPrice(100);
//		menuService.addMenu(menu);
//		List<CafeMenu> testMenu = menuService.getAll();
//		assertNotNull(testMenu);
//	}
////	
////	
////	
////	******************* Cafev Table Test Cases ***********************
////	
////	
//	@Test
//	public void testAddTable() {
//		CafeTable table = new CafeTable();
//		table.setTableId(1);
//		table.setRoomType("Ac");
//		table.setCapacity(5);
//		table.setIsAvailable("Available");
//		tableService.addTable(table);
//		
//		CafeTable table2 = tableService.getTablesById(1);
//		assertEquals(table.getCapacity(), table2.getCapacity());
//	}
//	
//	@Test
//	public void testUpdateTable() {
//		CafeTable table = tableService.getTablesById(1);
//		table.setCapacity(8);
//		tableService.addTable(table);
//		CafeTable table2 = tableService.getTablesById(1);
//		assertEquals(8, table2.getCapacity());
//	}
//	
//	
//	
//	@Test
//	public void testGetAllTables() {
//		CafeTable table = new CafeTable();
//		table.setRoomType("Ac");
//		table.setCapacity(5);
//		table.setIsAvailable("Available");
//		tableService.addTable(table);
//		
//		table = new CafeTable();
//		table.setRoomType("Non Ac");
//		table.setCapacity(8);
//		table.setIsAvailable("Not Available");
//		tableService.addTable(table);
//		
//		List<CafeTable> tables = tableService.getAllTables();
//		assertNotNull(tables);
//	}
//	
//	
//	@Test
//	public void testDeleteTable() {
//		CafeTable table = new CafeTable();
//		table.setRoomType("Ac");
//		table.setCapacity(5);
//		table.setIsAvailable("Available");
//		
//		CafeTable table1 = tableService.addTable(table);
//		CafeTable table2 = tableService.deleteTable(table1.getTableId());
//		
//		assertEquals(table1.getIsAvailable(), table2.getIsAvailable());
//	}
//	
//	
//	
////	
////	******************* Customer Test Cases ***********************
//	
//	
// 
//	
//	@Test
//	public void getCustomer() {
//		test();
//		Customer resultcust=custservice.getCustomerByEmail(cust.getCustomerEmail());
//		assertEquals(resultcust.getCustomerName(), cust.getCustomerName());
//	}
//	@Test
//	public void updateCust() {
//		test();
//		Customer resultcust=custservice.updateCustomer(cust);
//		assertEquals(cust.getCustomerPassword(), resultcust.getCustomerPassword());
//	}
//	@Test
//	public void addcust()
//	{
//		test();
//		Customer res=custservice.addCustomer(cust);
//		assertEquals(cust.getCustomerName(), res.getCustomerName());
//	}
//	
//	
//	
//	
//	//----Reservation
//	
//	
//	public Customer cust=new Customer();
//	public Reservation reservation=new Reservation();
//	@Test
//	void test() {
//			cust.setCustomerName("Bhaskar");
//			cust.setCustomerEmail("dharsha@gmail.com");
//			cust.setCustomerContact(8994358305l);
//			cust.setCustomerPassword("1234569");
//			cust.setCustomerId(7);
//			custservice.addCustomer(cust);
//			
//		CafeTable table = new CafeTable();
//		table.setTableId(1);
//		table.setRoomType("Ac");
//		table.setCapacity(5);
//		table.setIsAvailable("Available");
//		tableService.addTable(table);
//		List<CafeTable> tableList= new ArrayList();
//		tableList.add(table);
//		
//		reservation.setBookingdate(LocalDateTime.now());
//		reservation.setCustomer(cust);
//		reservation.setMessage("Welcome");
//		reservation.setNoOfPeople(3);
//		reservation.setStatus("Pending");
//		reservation.setTableList(tableList);
//		reservation.setVisitDate(LocalDate.now());
//		reservation.setVisitTime("6:30");
//		Reservation result=reservationservice.addReservation(reservation);
//		assertNotNull(result, "The reservation should not be null");
//		assertEquals(result.getMessage(), reservation.getMessage());
//	}
//	
//	@Test
//	public void getAllReservation() {
//		List<Reservation> reservations=reservationservice.getAllReservations();
//		assertNotNull(reservations);
//	}
//	
//	@Test
//	public void getReservationById() {
//		Reservation reservation=reservationservice.getReservationById(3);
//		assertNotNull(reservation, "The reservation should not be null");
//	}
//	
//	@Test
//	public void getReservationByMail() {
//		List<Reservation> reservations=reservationservice.getReservation("dharsha@gmail.com;");
//		assertNotNull(reservations);
//	}
//	
//	@Test
//	public void cancelReservation() {
//		Reservation reservation=reservationservice.cancelReservation(3);
//		assertNotNull(reservation, "The reservation should not be null");
//	}
//	@Test
//	public void changeStatus() {
//		Reservation reservation=reservationservice.updateReservationStatus(4);
//		assertEquals("confirmed", reservation.getStatus());
//	}
//	@Test
//	public void addReservation() {
//		Reservation result=reservationservice.addReservation(reservation);
//		assertNotNull(result, "The reservation should not be null");
//		assertEquals(result.getMessage(), reservation.getMessage());
//	}
//	
//	
//	
//	
//	@Test
//	void contextLoads() {
//	}

}
